package etec.com.br.appparmetros;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SegundaTela extends AppCompatActivity {

    //Objetos das TXTVIEWS
    TextView txtnome, txtemail;

    //variáveis auxiliares
    String nomeRecebido, emailRecebido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);

        //Recuperação dos valoree
        Intent telaAtual = getIntent();
        Bundle valores = telaAtual.getExtras();

        //Associando objetos para escrever as TXTVIEWS
        txtnome = (TextView) findViewById(R.id.txtNome);
        txtemail = (TextView) findViewById(R.id.txtEmail);

        //Pegando os valores passados
        nomeRecebido = valores.getString("nome");
        emailRecebido = valores.getString("email");

        //Mostrando os valores
        txtnome.setText(nomeRecebido);
        txtemail.setText(emailRecebido);
    }
}
