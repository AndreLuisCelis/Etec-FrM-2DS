package etec.com.br.appparmetros;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Objetos EDITEXTS
    EditText edNome, edEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Associando os Objetos
        edNome = (EditText) findViewById(R.id.edtNome);
        edEmail = (EditText) findViewById(R.id.edtEmail);

    }

    //Método que envia os dados
    public void enviar(View v){
        if (edNome.getText().toString().isEmpty()){
            edNome.setError("Preencha o nome");
            edNome.requestFocus();
        }else if (edEmail.getText().toString().isEmpty()){
            edEmail.setError("Preencha o E-mail");
            edEmail.requestFocus();
        }else {
            Intent tela2 = new Intent(MainActivity.this, SegundaTela.class);
            tela2.putExtra("nome",edNome.getText().toString());
            tela2.putExtra("email",edEmail.getText().toString());
            startActivity(tela2);
            Toast.makeText(this, "Dados enviados com sucesso!", Toast.LENGTH_LONG).show();
        }
    }
}
