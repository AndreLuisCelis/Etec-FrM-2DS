<?php 
include "modulos/cebecalhoemenu.php";
 ?>
 <form>
 	
 		<h2>ALUNO: Andre Luis Celis Nº19324</h2>
<h3>PROFESSOR: Caroline Milone</h3>
<h4>COMPONENTE CURRICULAR: PROGRAMAÇÃO WEB II</h4>
<p>Competência (s) Avaliada(s): 
Desenvolver sistemas para internet utilizando persistência em banco de dados, interface com o usuário e programação em lado servidor.
Base Tecnológica (s) Avaliada (s):
Introdução a scripts lado servidor Variáveis e tipos de dados

 	</p>
 </form>