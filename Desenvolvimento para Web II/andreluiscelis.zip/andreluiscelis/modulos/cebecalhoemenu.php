<!DOCTYPE html>
<html>
<head>
	<title>Atividade PHP </title>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/andreluiscelis/css/style.css">

	
</head>
<body>
 <header>
 	<h1> Atividade PhP</h1>
 	<nav>
 		<ul class="menu">
 			<a href="/andreluiscelis/modulos/exercicio01.php">Exercicio 1</a>
 			<a href="/andreluiscelis/modulos/exercicio02.php">Exercicio 2</a>
 			<a href="/andreluiscelis/modulos/exercicio03.php">Exercicio 3</a>
 			<a href="/andreluiscelis/modulos/exercicio04.php">Exercicio 4</a>
 			<a href="/andreluiscelis/modulos/exercicio05.php">Exercicio 5</a>
 			<a href="/andreluiscelis/modulos/exercicio06.php">Exercicio 6</a>
 			<a href="/andreluiscelis/modulos/exercicio07.php">Exercicio 7</a>
 			<a href="/andreluiscelis/modulos/exercicio08.php">Exercicio 8</a>
 			<a href="/andreluiscelis/modulos/exercicio09.php">Exercicio 9</a>
 			<a href="/andreluiscelis/modulos/exercicio10.php">Exercicio 10</a>
 	</nav>

 </header>
</body>
</html>