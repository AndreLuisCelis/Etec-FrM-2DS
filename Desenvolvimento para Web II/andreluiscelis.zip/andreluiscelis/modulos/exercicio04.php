<?php 
	include "cebecalhoemenu.php";
 ?>
 <form>
 	<p>4) Explique a diferença entre o uso de aspas duplas e aspas simples no PHP com um exemplo.</p>
 	<p>Com as aspas duplas não é necessário concatenar as variáveis pois isso é feito automaticamente , nas aspas simples as variáveis precisam ser concatenadas<br>

$nome=”André”;<br>
EX: Aspas duplas : echo “Ola $nome” ; // Ola André<br>
EX:Aspas simples  echo ‘Ola ’.$nome;   //Ola André</p>
 </form>