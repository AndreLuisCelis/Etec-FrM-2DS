<?php 
	include "cebecalhoemenu.php";
 ?>
 <form>
 	<p>1) Como funciona a geração de páginas dinâmicas na arquitetura cliente/servidor?</p>
 	<p>Funciona através de uma maquina em algum local remoto que recebe requisições do usuário através do navegador  e processa a solicitação efetua os cálculos se necessário e devolve o código HTML que é interpretado pelo browser</p>
 </form>