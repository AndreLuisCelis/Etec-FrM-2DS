<?php 
	include "cebecalhoemenu.php";
 ?>
 <form>
 	<p>3) Explique a função var_dump() e quando se utiliza.</p>
 	<p>A função var_dump() serve para ver qual  o tipo de uma varialvel e também quais são os seus valores , ela pode ser utilizada para testar tipos e valores de variáveis</p>
 </form>