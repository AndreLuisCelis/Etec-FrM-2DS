<?php 
	include "cebecalhoemenu.php";
 ?>
 <form>
 	<p>5) No trecho de código abaixo, qual será o resultado em cada exibição? Explique.</p>
 	<img src="../img/img.jpg">
 	<p>A primeira Saida é 11,5 pois 3/2 é 1,5 depois é somado 10 pois o php obedece a ordem de realização das operações confor me as regras da matemática

A segunda saída é 6,5 pois devido os parentes na soma ela é realizada primeiro

Na terceira saída vai ser False , pois a expressão 10+5 após o && é falsa e só poderia ser verdadeira se ambas as expressões fossem verdadeiras

Na quarta saída Vai ser True pois a primeira expressão é verdadeira e a condição || ou solicita que pelo menos uma das expressões sejam verdadeiras para atribuir o valor true</p>
 </form>