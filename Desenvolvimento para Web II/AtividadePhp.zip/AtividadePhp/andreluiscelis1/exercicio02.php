<?php 
	include "cebecalhoemenu.php";
 ?>
 <form>
 	<p>2) O que significa a frase: “A LINGUAGEM PHP É FRACAMENTE TIPADA”?</p>
 	<p>Significa que na Linguagem PHP não é necessário especificar qual é o tipo da variável declarada , ela atribui o valor conforme o dado que for especificado , também é possível mudar o tipo de dado da varial , por exemplo atribuir um inteiro a uma variável X e depois atribuir a mesma variável uma String</p>
 </form>