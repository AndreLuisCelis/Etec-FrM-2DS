package br.com.etec.apppesoideal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class Imc extends AppCompatActivity {

    EditText peso , altura;
    Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        peso = (EditText) findViewById(R.id.edtImcPeso);
        altura = (EditText) findViewById(R.id.edtImcAltura);
        calcular = (Button) findViewById(R.id.btnImcCalcular);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (peso.getText().toString().isEmpty()){
                    peso.setError("Por favor digite o peso");
                    peso.requestFocus();

                }else if (altura.getText().toString().isEmpty()){
                    altura.setError(" Por favor digite a Altura");
                    altura.requestFocus();

                }else {

                    Double imcPeso = Double.parseDouble(peso.getText().toString());
                    Double imcAltura = Double.parseDouble(altura.getText().toString());
                    Double imc = imcPeso/(imcAltura*imcAltura);
                    imc = Double.valueOf(String.format(Locale.US,"%.2f",imc));

                    if (imc<16){
                        Toast.makeText(Imc.this,"imc: "+imc+" Magreza Grave", Toast.LENGTH_LONG).show();

                    }else if (imc<17){
                        Toast.makeText(Imc.this,"imc: "+imc+" Magreza Moderada", Toast.LENGTH_LONG).show();

                    }else if (imc<18.5){
                        Toast.makeText(Imc.this, "imc: "+imc+" Magreza Leve", Toast.LENGTH_LONG).show();

                    }else if (imc<25){
                        Toast.makeText(Imc.this, "imc: "+imc+" Saudável", Toast.LENGTH_LONG).show();

                    }else if (imc<30){
                        Toast.makeText(Imc.this, "imc: "+imc+" Sobre Peso", Toast.LENGTH_LONG).show();

                    }else if (imc<35){
                        Toast.makeText(Imc.this, "imc: "+imc+ " Obesidade Grau I", Toast.LENGTH_LONG).show();

                    }else if (imc<40){
                        Toast.makeText(Imc.this, "imc: "+imc+ " Obesidade Grau II (severa)", Toast.LENGTH_LONG).show();

                    }else {
                        Toast.makeText(Imc.this, "imc: "+imc+ " Obesidade Grau III (morbida", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}
