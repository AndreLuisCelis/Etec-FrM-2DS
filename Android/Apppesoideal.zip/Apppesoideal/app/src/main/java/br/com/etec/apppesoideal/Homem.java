 package br.com.etec.apppesoideal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

 public class Homem extends AppCompatActivity {

    EditText nome , altura;  //declaração das variaveis para pegar os valores
     Button calcular;        // declaração do botão calcular


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homem);

        nome = (EditText) findViewById(R.id.nomeHomem); //associando as variaveis com os elemtos do xml activity
        altura = (EditText) findViewById(R.id.alturaHomem);
        calcular = (Button) findViewById(R.id.btnCalcularHomem);


        calcular.setOnClickListener(new View.OnClickListener() {//instanciando o botão calcular
            @Override
            public void onClick(View view) {

                if (nome.getText().toString().isEmpty()){// verifica se os valores forão preenchidos

                    nome.setError("Digite o nome Por Favor");// apresenta uma mensagem de erro caso o valor não esteja preenchido
                    nome.requestFocus();// coloca o focu na campo não preenchido

                } else if (altura.getText().toString().isEmpty()){

                    altura.setError(" Digite a Altura Por Favor");
                    altura.requestFocus();
                } else {


                    String nomeHomem = nome.getText().toString();// declara e instancia variavel para o nome
                    Double alturaHomem = Double.parseDouble(altura.getText().toString());// declara e instancia a variavel para altura
                    Double pesoIdeal = (72.7*alturaHomem)-58; // declara a varialve e faz o calculo do peso ideal
                     pesoIdeal = Double.valueOf(String.format(Locale.US,"%.2f",pesoIdeal));//Formata o numero de Casas depois da Virgula

                    Toast.makeText(Homem.this, nomeHomem + " Seu peso Ideal é: "+ pesoIdeal, Toast.LENGTH_LONG).show();
                }

            }
        });

    }
}
