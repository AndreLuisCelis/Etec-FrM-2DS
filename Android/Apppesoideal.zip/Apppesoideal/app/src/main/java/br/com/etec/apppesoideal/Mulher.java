package br.com.etec.apppesoideal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class Mulher extends AppCompatActivity {

    EditText nome , altura;
    Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mulher);

        nome = (EditText) findViewById(R.id.edtAlturaMulher);
        altura =(EditText) findViewById(R.id.edtAlturaMulher);
        calcular = (Button) findViewById(R.id.btnCalcularMulher);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nome.getText().toString().isEmpty()){
                    nome.setError(" Por Favor digite o nome");
                    nome.requestFocus();

                }else if (altura.getText().toString().isEmpty()){
                    altura.setError(" Por Favor digite a Altura");
                    altura.requestFocus();

                }else {

                    String nomeMulher = nome.getText().toString();
                    Double alturaMulher = Double.parseDouble(altura.getText().toString());
                    Double pesoIdeal = (62.1*alturaMulher)-44.7;
                    pesoIdeal = Double.valueOf(String.format(Locale.US,"%.2f",pesoIdeal));

                    Toast.makeText(Mulher.this,nomeMulher + " seu peso ideal é: "+pesoIdeal, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
